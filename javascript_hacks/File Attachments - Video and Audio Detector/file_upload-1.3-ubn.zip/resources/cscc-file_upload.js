var media_extensions = "|3g2|3gp|aif|asf|asx|avi|flv|iff|mkv|m3u|m4a|m4v|mid|mov|mp3|mp4|mpa|mpg|mpeg|ra|rm|srt|vob|wav|wma|wmv|ogg|webm|vob|trec|camrec|camproj|";
$j(document).ready(function () {
	var url = window.location.href;
	var text_editor = setInterval(function(){ 
		if($j("button.tox-tbtn").length) {
			$j("button.tox-tbtn[title='Add content']").attr("onclick","file_upload();");
			clearInterval(text_editor);
		}
	}, 1000);
	
	$j("#bottom_Submit, input[name='bottom_Submit'], input[name='bottom_Post Entry'], #bottom_submitBtn").click(function() {
		if(url.indexOf("execute/content/file") > 0 || url.indexOf("discussionboard/message/message_edit") > 0 || url.indexOf("discussionboard/do/message?action=create") > 0) {
			if(!check_file(url)) {
				return false;
			}
		} else if(url.indexOf("execute/blti/contentHandlerPlacement") > 0) {
			if(!check_files("attachedFile_table_body")) {
				return false;
			}
		} else {
			if(url.indexOf("manageAssignment") > 0) {
				$j("#bottom_Submit").attr("onclick", "");
			}
			if(!check_files("newFile_table_body")) {
				return false;
			}
		}
	});

});
function file_upload() {
	$j("#bottom_Submit, input[name='bottom_Submit'], input[name='bottom_Post Entry'], input[name='bottom_Save and Exit'], input[name='bottom_Save and Continue'], #bottom_submitBtn").on("click", function() {
		var media_files = false;
		var media_file_list = "";
		
		$j("#messagetext_ifr, #htmlData_text_ifr, #descriptiontext_ifr, .tox-edit-area__iframe").contents().find("#tinymce div[data-ephox-embed-iri]").each(function(index, value) {
			var file_embed = $j(this).attr("data-ephox-embed-iri");
			var file_name = file_embed.substr((file_embed.lastIndexOf('/')+1));
			var file_extension = file_embed.substr((file_embed.lastIndexOf('.')+1));		

			if (file_embed.indexOf(document.domain+"/sessions/") > -1 && media_extensions.indexOf("|"+file_extension+"|") > -1) {
				media_files = true;
				media_file_list += "<li>"+decodeURIComponent(file_name)+"</li>";
			}

		});
		
		if(media_files) {
			if($j(this).attr("name") == "bottom_Save and Exit") {
				$j(this).attr("onclick","");
			}
			load_error(media_file_list);
			email_support(media_file_list);		
			return false;
		} else {
			return true;
		}
	});
}

function check_files(object_id) {
	var media_files = false;
	var media_file_list = "";
		
	$j("#"+object_id+" tr").each(function() {
		var file_status = $j(this).children(":last").text().replace(/\s/g,'');
		if(file_status!="Unmarkforremoval") {
			var file_name = $j(this).children(":first").text();
			var file_extension = file_name.substr((file_name.lastIndexOf('.') +1)).replace(/\s/g,'').toLowerCase();
						
			if (media_extensions.indexOf("|"+file_extension+"|") > -1) {
				media_files = true;
				media_file_list += "<li>"+file_name+"</li>";
			}
		}
	});
	if(media_files) {
		load_error(media_file_list);
		//email_support(media_file_list);
		return false;
	} else {
		return true;
	}
}
function check_file(url) {
	var field_id = "#sourceFile_selectedFileName";
	if(url.indexOf("discussionboard/message/message_edit") > 0 || url.indexOf("discussionboard/do/message?action=create") > 0) {
		field_id = "#msgAttachment_selectedFileName"
	}
	var media_files = false;
	var file_name = $j(field_id).text();
	
	var file_extension = file_name.substr((file_name.lastIndexOf('.') +1)).replace(/\s/g,'').toLowerCase();
	if (media_extensions.indexOf("|"+file_extension+"|") > -1) {
		media_files = true;
	}
	if(media_files) {
		load_error("<li>"+file_name+"</li>");
		//email_support("<li>"+file_name+"</li>");
		return false;
	} else {
		return true;
	}	
}
function load_error(media_list) {
	var dimensions = document.viewport.getDimensions();
	var width = Math.round(dimensions.width * 0.8);
	var height = Math.round(dimensions.height * 0.8);
	var el_if = document.getElementById('osc-BasicLTI-overlay');
	var osc_lbParam = {
		defaultDimensions : { w : width, h : height },
		title : "Audio and Video Files",
		openLink : el_if,
		contents : '<div style="margin:2em;"><h1>Do Not Upload Media Files into Blackboard</h1><p style="margin-bottom:1em;">If you  upload media directly to Blackboard it may cause the entire Blackboard system to slow down.</p><p style="margin-bottom:1em;">View <a href="https://help.cscc.edu/article/159-how-to-insert-videos-into-blackboard" target="_blank">How to Add Audio or Video Files into Blackboard</a></p><p style="margin-bottom:1em;">CSCC uses a streaming service called "Kaltura" to store and deliver all audio and video files which are to be shared with students as part of a course.  All media files should be stored using Kaltura as it automatically adapts the format of the video according to the device the student is using to view it. Media stored on Kaltura is easily incorporated into Blackboard courses.</p><p style="margin-bottom:1em;">Please remove the following files from your attachment list and upload them into Kaltura instead:</p><ul style="margin:1em 4em; list-style-type:disc;">'+media_list+'</ul><p style="margin-bottom:1em;">If you have questions or need further assistance then please contact the Support Center at <a href="mailto:support@yourschool.edu">support@yourschool.edu</a> or 614-555-5555.</p></div>',
		closeOnBodyClick : true,
		showCloseLink : true,
		useDefaultDimensionsAsMinimumSize : true,
		ajax: false
	};
	var osc_lightbox = new lightbox.Lightbox(osc_lbParam);
	osc_lightbox.open();
}

function email_support(media_files) {
	$j.ajax({
		type: "POST",
		url : "[email_url]",
		data: {"course": cscc_course_id, "role": cscc_course_role, "email":cscc_user_email, "name":cscc_fullname, "files":media_files},
		success : function (data) {
			//alert(data);
		},
		error: function (xhr, ajaxOptions, thrownError) {
			//alert(xhr.status+" - "+thrownError);
		}
	});
}