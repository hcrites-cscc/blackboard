var media_extensions = "|3g2|3gp|aif|asf|asx|avi|flv|iff|mkv|m3u|m4a|m4v|mid|mov|mp3|mp4|mpa|mpg|mpeg|ra|rm|srt|vob|wav|wma|wmv|ogg|webm|vob|trec|camrec|camproj|";

function check_files(object_id) {
	var media_files = false;
	var media_file_list = "";
	$j("#"+object_id+" tr").each(function() {
		var file_status = $j(this).children(":last").text().replace(/\s/g,'');
		if(file_status!="Unmarkforremoval") {
			var file_name = $j(this).children(":first").text();
			var file_extension = file_name.substr((file_name.lastIndexOf('.') +1)).replace(/\s/g,'').toLowerCase();
			if (media_extensions.indexOf("|"+file_extension+"|") > -1) {
				media_files = true;
				media_file_list += "<li>"+file_name+"</li>";
			}
		}
	});
	if(media_files) {
		load_error(media_file_list);
		//email_support(media_file_list);
		return false;
	} else {
		return true;
	}
}

function load_error(media_list) {
	var dimensions = document.viewport.getDimensions();
	var width = Math.round(dimensions.width * 0.8);
	var height = Math.round(dimensions.height * 0.8);
	var el_if = document.getElementById('osc-BasicLTI-overlay');
	var osc_lbParam = {
		defaultDimensions : { w : width, h : height },
		title : "Audio and Video Files",
		openLink : el_if,
		contents : '<div style="margin:2em;"><h1>Do Not Upload Media Files into Blackboard</h1><p style="margin-bottom:1em;">If you  upload media directly to Blackboard it may cause the entire Blackboard system to slow down.</p><p style="margin-bottom:1em;">View <a href="https://help.cscc.edu/article/159-how-to-insert-videos-into-blackboard" target="_blank">How to Add Audio or Video Files into Blackboard</a></p><p style="margin-bottom:1em;">CSCC uses a streaming service called "Kaltura" to store and deliver all audio and video files which are to be shared with students as part of a course.  All media files should be stored using Kaltura as it automatically adapts the format of the video according to the device the student is using to view it. Media stored on Kaltura is easily incorporated into Blackboard courses.</p><p style="margin-bottom:1em;">Please remove the following files from your attachment list and upload them into Kaltura instead:</p><ul style="margin:1em 4em; list-style-type:disc;">'+media_list+'</ul><p style="margin-bottom:1em;">If you have questions or need further assistance then please contact the Faculty Assistance Center at <a href="mailto:teaching@cscc.edu">teaching@cscc.edu</a> or 614-287-5991.</p></div>',
		closeOnBodyClick : true,
		showCloseLink : true,
		useDefaultDimensionsAsMinimumSize : true,
		ajax: false
	};
	var osc_lightbox = new lightbox.Lightbox(osc_lbParam);
	osc_lightbox.open();
}

function email_support(media_files) {
	$j.ajax({
		type: "POST",
		url : "[email_url]",
		data: {"course": cscc_course_id, "role": cscc_course_role, "email":cscc_user_email, "name":cscc_fullname, "files":media_files}
	});
}