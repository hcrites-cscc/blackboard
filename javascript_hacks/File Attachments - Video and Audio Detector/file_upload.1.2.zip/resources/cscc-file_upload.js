var media_extensions = "|3g2|3gp|aif|asf|asx|avi|flv|iff|mkv|m3u|m4a|m4v|mid|mov|mp3|mp4|mpa|mpg|mpeg|ra|rm|srt|vob|wav|wma|wmv|ogg|webm|vob|trec|camrec|camproj|";
var tinymce_media_buttons = "#bodytext_media, #descriptiontext_media, #definitiontext_media, #blog_desc_text_media, #instructionstext_media, #blogEntry_desc_text_media, #questionText.text_media, .mce_media, #mce_fullscreen_media";
$j(document).ready(function () {
	var url = window.location.href;
	var text_editor = setInterval(function(){ 
		if($j(tinymce_media_buttons).length) {
			$j(tinymce_media_buttons).hide();
			$j("a.mce_bb_file, #htmlData_text_bb_file").attr("onclick","file_upload();");
			clearInterval(text_editor);
		}
	}, 1000);
	
	$j("#bottom_Submit, input[name='bottom_Submit'], input[name='bottom_Post Entry'], #bottom_submitBtn").click(function() {
		if(url.indexOf("execute/content/file") > 0 || url.indexOf("discussionboard/message/message_edit") > 0 || url.indexOf("discussionboard/do/message?action=create") > 0) {
			if(!check_file(url)) {
				return false;
			}
		} else {
			if(url.indexOf("manageAssignment") > 0) {
				$j("#bottom_Submit").attr("onclick", "");
			}
			if(!check_files("newFile_table_body")) {
				return false;
			}
		}
	});

});
function file_upload() {
	var win = window.open("", "bb_file", "height=675,width=1200,status=1,scrollbars=1,resizable=1" );
	var insert_javascript_1 = "var cscc_course_id = \""+cscc_course_id+"\";var cscc_course_role = \""+cscc_course_role+"\";cscc_course_role = cscc_course_role.replace(\"blackboard.data.course.CourseMembership$Role:\",\"\");var cscc_user_email = \""+cscc_user_email+"\";var cscc_fullname = \""+cscc_fullname+"\";function initiate() {$j('#bottom_Submit').click(function() {if(!check_files('imagepackage_table_body')) {return false;}});}initiate();";
	var file_upload_timer = setInterval(function(){ 
		if(win.document.body.innerHTML) {
			var upload_script = document.getElementById('cscc-file_upload');
			var upload_script_src = upload_script.getAttribute('src');
			var _in = win.document.getElementById('containerdiv');
			
			var script_node_2 = win.document.createElement('script');
			script_node_2.type = "text/javascript";
			script_node_2.charset = "utf-8";
			script_node_2.src = upload_script_src.replace("cscc-file_upload.js", "cscc-file_embed.js");
			_in.appendChild(script_node_2);
			
			var script_node_1 = win.document.createElement('script');
			script_node_1.type = "text/javascript";
			script_node_1.innerHTML = insert_javascript_1;
			_in.appendChild(script_node_1);
			
			clearInterval(file_upload_timer);
		}
	}, 1000);
}

function check_files(object_id) {
	var media_files = false;
	var media_file_list = "";
	$j("#"+object_id+" tr").each(function() {
		var file_status = $j(this).children(":last").text().replace(/\s/g,'');
		if(file_status!="Unmarkforremoval") {
			var file_name = $j(this).children(":first").text();
			var file_extension = file_name.substr((file_name.lastIndexOf('.') +1)).replace(/\s/g,'').toLowerCase();
			if (media_extensions.indexOf("|"+file_extension+"|") > -1) {
				media_files = true;
				media_file_list += "<li>"+file_name+"</li>";
			}
		}
	});
	if(media_files) {
		load_error(media_file_list);
		//email_support(media_file_list);
		return false;
	} else {
		return true;
	}
}
function check_file(url) {
	var field_id = "#sourceFile_selectedFileName";
	if(url.indexOf("discussionboard/message/message_edit") > 0 || url.indexOf("discussionboard/do/message?action=create") > 0) {
		field_id = "#msgAttachment_selectedFileName"
	}
	var media_files = false;
	var file_name = $j(field_id).text();
	
	var file_extension = file_name.substr((file_name.lastIndexOf('.') +1)).replace(/\s/g,'').toLowerCase();
	if (media_extensions.indexOf("|"+file_extension+"|") > -1) {
		media_files = true;
	}
	if(media_files) {
		load_error("<li>"+file_name+"</li>");
		//email_support("<li>"+file_name+"</li>");
		return false;
	} else {
		return true;
	}	
}
function load_error(media_list) {
	var dimensions = document.viewport.getDimensions();
	var width = Math.round(dimensions.width * 0.8);
	var height = Math.round(dimensions.height * 0.8);
	var el_if = document.getElementById('osc-BasicLTI-overlay');
	var osc_lbParam = {
		defaultDimensions : { w : width, h : height },
		title : "Audio and Video Files",
		openLink : el_if,
		contents : '<div style="margin:2em;"><h1>Do Not Upload Media Files into Blackboard</h1><p style="margin-bottom:1em;">If you  upload media directly to Blackboard it may cause the entire Blackboard system to slow down.</p><p style="margin-bottom:1em;">View <a href="https://help.cscc.edu/article/159-how-to-insert-videos-into-blackboard" target="_blank">How to Add Audio or Video Files into Blackboard</a></p><p style="margin-bottom:1em;">CSCC uses a streaming service called "Kaltura" to store and deliver all audio and video files which are to be shared with students as part of a course.  All media files should be stored using Kaltura as it automatically adapts the format of the video according to the device the student is using to view it. Media stored on Kaltura is easily incorporated into Blackboard courses.</p><p style="margin-bottom:1em;">Please remove the following files from your attachment list and upload them into Kaltura instead:</p><ul style="margin:1em 4em; list-style-type:disc;">'+media_list+'</ul><p style="margin-bottom:1em;">If you have questions or need further assistance then please contact the Faculty Assistance Center at <a href="mailto:teaching@cscc.edu">teaching@cscc.edu</a> or 614-287-5991.</p></div>',
		closeOnBodyClick : true,
		showCloseLink : true,
		useDefaultDimensionsAsMinimumSize : true,
		ajax: false
	};
	var osc_lightbox = new lightbox.Lightbox(osc_lbParam);
	osc_lightbox.open();
}

function email_support(media_files) {
	$j.ajax({
		type: "POST",
		url : "[email_url]",
		data: {"course": cscc_course_id, "role": cscc_course_role, "email":cscc_user_email, "name":cscc_fullname, "files":media_files},
		success : function (data) {
			//alert(data);
		},
		error: function (xhr, ajaxOptions, thrownError) {
			//alert(xhr.status+" - "+thrownError);
		}
	});
}
